# ============================================================
# Green Uncertainty–GTFP Panel Analysis in R / Google Colab
# Missing values are never fabricated; they are handled by model-specific complete-case deletion.
# ============================================================

# In Google Colab, select Runtime > Change runtime type > R.
# Run this line once to install the required packages:
# install.packages(c('readxl','dplyr','tidyr','stringr','openxlsx','plm','fixest','car','lmtest','sandwich','spdep','zip'))

options(stringsAsFactors = FALSE, scipen = 999)

# ---------- 1. Upload the data file ----------
# In Colab/R, the easiest option is to upload panel-data.xlsx to /content using the Files panel.
# Upload the Excel file manually through the Colab Files panel before running this script.
# Click Upload in the Files panel and select your .xlsx or .xls file.
excel_candidates <- list.files('/content', pattern='\\.(xlsx|xls)$', full.names=TRUE, ignore.case=TRUE)
if (length(excel_candidates) == 0) {
  stop('No Excel file was found in /content. Upload the data file through the Colab Files panel, then run this script again.')
}
# Use the most recently uploaded Excel file if multiple files are present.
DATA_FILE <- excel_candidates[which.max(file.info(excel_candidates)$mtime)]
cat('Selected data file:', basename(DATA_FILE), '\n')

# ---------- 2. Install/load packages ----------
required <- c('readxl','dplyr','tidyr','stringr','openxlsx','plm','fixest','car','lmtest','sandwich','spdep')
missing_pkg <- required[!vapply(required, requireNamespace, logical(1), quietly=TRUE)]
if (length(missing_pkg)) {
  install.packages(missing_pkg, repos='https://cloud.r-project.org', quiet=TRUE)
}
library(readxl); library(dplyr); library(tidyr); library(stringr); library(openxlsx)
library(plm); library(fixest); library(car); library(lmtest); library(sandwich)
library(spdep)

OUTDIR <- '/content/green_analysis_outputs'
dir.create(OUTDIR, showWarnings=FALSE, recursive=TRUE)

# ---------- 3. Read and clean the data ----------
df <- readxl::read_excel(DATA_FILE, na=c('NA','N/A','null','NULL',''))
names(df) <- str_trim(names(df))
rename_if_present <- function(data, old, new) {
  if (old %in% names(data) && !(new %in% names(data))) names(data)[names(data)==old] <- new
  data
}
df <- rename_if_present(df, 'GF', 'GFit')
df <- rename_if_present(df, 'COC', 'CO2pc')
df <- rename_if_present(df, 'POP', 'PopLog')
required_cols <- c('country_id','Country','ISO3','Region','Year','GTFP','WUI','GFit','RID','GDP','FDI','NRR','Pop','URB','CO2pc')
missing_cols <- setdiff(required_cols, names(df))
if (length(missing_cols)) stop(paste('Missing required columns:', paste(missing_cols, collapse=', ')))

numeric_cols <- intersect(c('Year','GTFP','WUI','GFit','KOF_TradeGlob','RID','GDP','FDI','NRR','Pop','PopLog','URB','CO2pc'), names(df))
df[numeric_cols] <- lapply(df[numeric_cols], function(x) as.numeric(as.character(x)))
df <- df %>% arrange(country_id, Year) %>%
  mutate(
    ln_Pop = log(pmax(Pop, 1)),
    ln_GDPpc = GDP,
    WUI_z = as.numeric(scale(WUI)),
    RID_z = as.numeric(scale(RID)),
    WUI_RID = WUI_z * RID_z,
    L1_GTFP = lag(GTFP), .by=country_id
  )
write.csv(df, file.path(OUTDIR,'cleaned_panel_used.csv'), row.names=FALSE, na='')

# ---------- 4. Helper functions ----------
stars <- function(p) ifelse(is.na(p),'',ifelse(p<.01,'***',ifelse(p<.05,'**',ifelse(p<.10,'*',''))))
model_tidy <- function(model, model_name, vars=NULL) {
  # Extract results through fixest accessors; this avoids version-dependent table layouts.
  estimates <- stats::coef(model)
  std_errors <- fixest::se(model)
  p_values <- fixest::pvalue(model)
  common <- intersect(names(estimates), names(std_errors))
  common <- intersect(common, names(p_values))
  ct <- data.frame(
    Variable=common,
    Estimate=as.numeric(estimates[common]),
    Std_Error=as.numeric(std_errors[common]),
    Statistic=as.numeric(estimates[common] / std_errors[common]),
    P_Value=as.numeric(p_values[common]),
    row.names=NULL
  )
  if (!is.null(vars)) ct <- ct %>% filter(Variable %in% vars)
  ct %>% mutate(Model=model_name, Significance=stars(P_Value)) %>%
    select(Model, Variable, Estimate, Std_Error, Statistic, P_Value, Significance)
}
round_output <- function(x, digits=4) {
  if (is.data.frame(x)) {
    x[] <- lapply(x, function(col) if (is.numeric(col)) round(col, digits) else col)
    return(x)
  }
  if (is.matrix(x) && is.numeric(x)) return(round(x, digits))
  if (is.numeric(x)) return(round(x, digits))
  x
}
write_table <- function(x, file) {
  # Round displayed table values only; model estimation uses full precision.
  write.xlsx(round_output(x, 4), file.path(OUTDIR,file), overwrite=TRUE)
}

# ---------- 5. Descriptive statistics ----------
main_vars <- c('GTFP','WUI','GFit','RID','GDP','FDI','NRR','ln_Pop','URB','CO2pc')
desc <- df %>% select(all_of(main_vars)) %>%
  summarise(across(everything(), list(N=~sum(!is.na(.)), Mean=~mean(.,na.rm=TRUE), SD=~sd(.,na.rm=TRUE), Min=~min(.,na.rm=TRUE), Median=~median(.,na.rm=TRUE), Max=~max(.,na.rm=TRUE)))) %>%
  pivot_longer(everything(), names_to=c('Variable','Statistic'), names_pattern='^(.*)_(N|Mean|SD|Min|Median|Max)$', values_to='Value') %>%
  pivot_wider(names_from=Statistic, values_from=Value)
write_table(desc, 'table1_descriptive_statistics.xlsx')
write_table(cor(df[main_vars], use='pairwise.complete.obs'), 'tableA2_correlation_matrix.xlsx')

# ---------- 6. Missingness audit and VIF ----------
miss <- data.frame(Variable=names(df), Missing_N=colSums(is.na(df))) %>% mutate(Missing_pct=100*Missing_N/nrow(df))
write_table(miss, 'missingness_audit.xlsx')
vif_data <- df %>% select(all_of(c('WUI','GFit','RID','GDP','FDI','NRR','ln_Pop','URB','CO2pc'))) %>% drop_na()
vif_fit <- lm(WUI ~ GFit + RID + GDP + FDI + NRR + ln_Pop + URB + CO2pc, data=vif_data)
vif_tab <- data.frame(Variable=names(car::vif(vif_fit)), VIF=as.numeric(car::vif(vif_fit)))
write_table(vif_tab, 'tableA3_vif.xlsx')

# ---------- 7. Fixed effects, mediation, and moderation models ----------
controls <- 'GDP + FDI + NRR + ln_Pop + URB + CO2pc'
complete_main <- df %>% drop_na(GTFP,L1_GTFP,WUI,RID,GDP,FDI,NRR,ln_Pop,URB,CO2pc)
complete_med <- df %>% drop_na(GFit,WUI,RID,GDP,FDI,NRR,ln_Pop,URB,CO2pc)
complete_out <- df %>% drop_na(GTFP,L1_GTFP,WUI,GFit,RID,GDP,FDI,NRR,ln_Pop,URB,CO2pc)
fe_base <- feols(as.formula(paste('GTFP ~ L1_GTFP + WUI +',controls,'| country_id + Year')), complete_main, cluster=~country_id)
fe_med_a <- feols(as.formula(paste('GFit ~ WUI + RID +',controls,'| country_id + Year')), complete_med, cluster=~country_id)
fe_med_b <- feols(as.formula(paste('GTFP ~ L1_GTFP + WUI + GFit + RID +',controls,'| country_id + Year')), complete_out, cluster=~country_id)
complete_mod <- df %>% drop_na(GTFP,L1_GTFP,WUI_z,RID_z,WUI_RID,GDP,FDI,NRR,ln_Pop,URB,CO2pc)
fe_mod <- feols(as.formula(paste('GTFP ~ L1_GTFP + WUI_z + RID_z + WUI_RID +',controls,'| country_id + Year')), complete_mod, cluster=~country_id)
model_vars <- c('L1_GTFP','WUI','WUI_z','GFit','RID','RID_z','WUI_RID','GDP','FDI','NRR','ln_Pop','URB','CO2pc')
tab3 <- bind_rows(model_tidy(fe_base,'Baseline FE',model_vars), model_tidy(fe_med_a,'Mediator equation',model_vars), model_tidy(fe_med_b,'Outcome with GFit',model_vars), model_tidy(fe_mod,'Moderation FE',model_vars))
write_table(tab3, 'table3_fixed_effects_mediation_moderation.xlsx')

a <- coef(fe_med_a)['WUI']; b <- coef(fe_med_b)['GFit']; direct <- coef(fe_med_b)['WUI']
med <- data.frame(Path=c('a: WUI -> GFit','b: GFit -> GTFP',"c': WUI -> GTFP | GFit",'Indirect effect a*b'), Estimate=c(a,b,direct,a*b))
write_table(med, 'table5_mediation_analysis.xlsx')
write_table(model_tidy(fe_mod,'Moderation FE',c('WUI_z','RID_z','WUI_RID')), 'table6_moderation_analysis.xlsx')

# ---------- 8. Sample splits ----------
run_split <- function(data, label) {
  d <- data %>% drop_na(GTFP,L1_GTFP,WUI,GDP,FDI,NRR,ln_Pop,URB,CO2pc)
  if (nrow(d)<30) return(data.frame())
  m <- feols(as.formula(paste('GTFP ~ L1_GTFP + WUI +',controls,'| country_id + Year')), d, cluster=~country_id)
  data.frame(Subsample=label, WUI_coefficient=coef(m)['WUI'], Std_Error=se(m)['WUI'], P_Value=pvalue(m)['WUI'], N=nobs(m))
}
splits <- bind_rows(run_split(filter(df,Region=='Asia'),'Asia only'), run_split(filter(df,Region=='Africa'),'Africa only'), run_split(filter(df,Year<2015),'Pre-2015'), run_split(filter(df,Year>=2015),'Post-2015'))
write_table(splits, 'tableA5_sample_splits.xlsx')

# ---------- 9. Moran's I using K-nearest-neighbour matrices ----------
# Geographic Moran I requires an official country-centroid file if geographic coordinates are available.
# Coordinates are never fabricated; therefore, only economic and trade Moran statistics are computed from available variables,
# and a requirements file is created for official country_centroids.csv input.
# For one-dimensional economic/trade metrics, construct an spdep-compatible nb object directly.
make_1d_knn_nb <- function(x, k) {
  n <- length(x)
  neighbors <- lapply(seq_len(n), function(i) {
    distances <- abs(x - x[i])
    distances[i] <- Inf
    order(distances)[seq_len(min(k, n - 1))]
  })
  class(neighbors) <- 'nb'
  attr(neighbors, 'region.id') <- as.character(seq_len(n))
  attr(neighbors, 'sym') <- FALSE
  neighbors
}
moran_rows <- data.frame()
for (yr in sort(unique(df$Year))) {
  cross <- df %>% filter(Year==yr) %>% drop_na(GTFP) %>% distinct(ISO3,.keep_all=TRUE)
  if (nrow(cross)<8) next
  for (kind in c('economic','trade')) {
    metric_name <- if (kind=='economic') 'GDP' else 'RID'
    cross2 <- cross %>% drop_na(all_of(metric_name))
    if (nrow(cross2) < 8) next
    metric <- cross2[[metric_name]]
    k <- min(5, nrow(cross2)-1)
    nb <- make_1d_knn_nb(metric, k=k)
    lw <- spdep::nb2listw(nb, style='W', zero.policy=TRUE)
    mi <- spdep::moran.test(cross2$GTFP, lw, zero.policy=TRUE)
    moran_rows <- bind_rows(moran_rows, data.frame(Year=yr, Matrix=kind, Moran_I=unname(mi$estimate[1]), P_Value=mi$p.value, N=nrow(cross2)))
  }
}
write_table(moran_rows, 'table2_moran_economic_trade_by_year.xlsx')
write_table(data.frame(Note='Geographic Moran I cannot be computed without official country coordinates. Add country_centroids.csv with columns ISO3,lat,lon to complete it.'), 'spatial_data_requirements.xlsx')

# ---------- 10. Generate all remaining paper tables ----------
# Tables requiring unavailable raw inputs are written as transparent templates with status labels.
country_table <- df %>% distinct(country_id, Country, ISO3, Region) %>% arrange(Region, Country) %>%
  mutate(No=seq_len(n()), GPR_subsample='Not available in current workbook') %>%
  select(No, Country, ISO3, Region, GPR_subsample)
write_table(country_table, 'tableA1_country_sample.xlsx')

# Table 2b: RID subgroup Moran results using the same one-dimensional KNN construction.
rid_moran <- data.frame()
rid_median <- median(df$RID, na.rm=TRUE)
for (grp in c('Low RID','High RID')) {
  for (kind in c('economic','trade')) {
    metric_name <- if (kind=='economic') 'GDP' else 'RID'
    dsub <- df %>% filter(if (grp=='Low RID') RID <= rid_median else RID > rid_median) %>%
      filter(!is.na(GTFP), !is.na(.data[[metric_name]])) %>% distinct(ISO3,.keep_all=TRUE)
    if (nrow(dsub) < 8) next
    metric <- dsub[[metric_name]]; k <- min(5,nrow(dsub)-1)
    nb <- make_1d_knn_nb(metric,k); lw <- spdep::nb2listw(nb, style='W', zero.policy=TRUE)
    mi <- spdep::moran.test(dsub$GTFP,lw,zero.policy=TRUE)
    rid_moran <- bind_rows(rid_moran,data.frame(Subgroup=grp,Matrix=kind,Moran_I=unname(mi$estimate[1]),P_Value=mi$p.value,N=nrow(dsub)))
  }
}
write_table(rid_moran, 'table2b_moran_RID_subgroups.xlsx')

write_table(data.frame(
  Effect=c('Direct effect','Indirect effect','Total effect','Spatial lag coefficient'),
  Estimate=NA_real_, Std_Error=NA_real_, P_Value=NA_real_,
  Status='Requires a formally specified and estimated Spatial Durbin Model with a validated spatial-weight matrix'
), 'table4_sdm_effects.xlsx')

write_table(data.frame(
  Parameter=c('rho_high_RID','rho_low_RID','LR test: rho_high = rho_low','Permutation p-value: subgroup Moran difference'),
  Estimate=NA_real_, P_Value=NA_real_,
  Status='Requires spatial-regimes estimation and a formally defined permutation test'
), 'table7_spatial_regimes_H8.xlsx')

write_table(data.frame(
  Check=c('GPR subsample (14 countries)','Alternative spatial weight matrices'),
  Sign=NA_character_, Comparison_to_baseline=NA_character_, Consistent=NA_character_,
  Status='Requires GPR data and validated spatial-weight matrices not included in the current workbook'
), 'table8_robustness_summary.xlsx')

write_table(data.frame(
  Specification=c('Super-efficiency SBM-DEA','Standard non-global ML index','Additional undesirables: SO2 and PM2.5'),
  WUI_coefficient=NA_real_, Std_Error=NA_real_, P_Value=NA_real_, N=NA_integer_,
  Status='Requires alternative GTFP indices and DEA raw inputs not included in the current workbook'
), 'tableA4_alternative_GTFP.xlsx')

write_table(data.frame(
  Model=c('SAR spatial lag','SEM spatial error','SDM baseline'), WUI_coefficient=NA_real_,
  Log_likelihood=NA_real_, AIC=NA_real_,
  Status='Requires a formally specified spatial panel model and validated spatial-weight matrix'
), 'tableA6_alternative_spatial_estimators.xlsx')

write_table(data.frame(
  Diagnostic=c('Difference-in-Hansen: GFit instruments','Difference-in-Hansen: WUI instruments','One-step vs two-step comparison'),
  Statistic=NA_real_, P_Value=NA_real_,
  Status='Requires System GMM estimation with explicit instrument subsets'
), 'tableA7_endogeneity_diagnostics.xlsx')

# ---------- 11. Combined Excel workbook, ZIP, and download ----------
all_xlsx <- list.files(OUTDIR, pattern='\\.xlsx$', full.names=TRUE)
all_xlsx <- all_xlsx[basename(all_xlsx) != 'ALL_RESULTS_GREEN_ANALYSIS.xlsx']
wb <- createWorkbook()
for (f in all_xlsx) {
  sheet <- substr(gsub('[^A-Za-z0-9_]','_',tools::file_path_sans_ext(basename(f))),1,31)
  addWorksheet(wb,sheet); writeData(wb,sheet,read.xlsx(f))
}
MASTER <- file.path(OUTDIR,'ALL_RESULTS_GREEN_ANALYSIS.xlsx')
saveWorkbook(wb, MASTER, overwrite=TRUE)
ZIP <- '/content/green_analysis_outputs.zip'
if (file.exists(ZIP)) file.remove(ZIP)
old_wd <- getwd()
setwd(OUTDIR)
status <- system2('zip', c('-q', '-j', shQuote(ZIP), shQuote(list.files(OUTDIR, full.names=FALSE))))
setwd(old_wd)
if (!identical(status, 0L)) warning('Automatic ZIP creation failed; compress the output folder manually if needed.')
cat('\nAnalysis completed successfully. Results are in:', OUTDIR, '\n')
cat('Combined Excel workbook:', MASTER, '\n')
cat('ZIP file:', ZIP, '\n')

# Download the ZIP file from the Colab Files panel:
# /content/green_analysis_outputs.zip
cat('Open the Colab Files panel and download:', ZIP, '\n')


